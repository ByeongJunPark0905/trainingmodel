"""project4 URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from django.conf.urls import include, url
from django.views.generic import RedirectView
from django.conf import settings
from django.conf.urls.static import static

from page import views


urlpatterns = [
    url(r'^admin/', admin.site.urls),
    url(r'^$', views.main, name='main'),
    url(r'^main(?P<pk>\d+)/', views.main), # 이게 있어야 뒤에 추가가 가능
    url(r'^login2/', views.login2, name='login2'),
    url(r'^login3/', views.login3, name='login3'),
    
    url(r'^service2_info/', views.service2_info, name='service2_info'),
    url(r'^service3_info/', views.service3_info, name='service3_info'),
    url(r'^service4_info/', views.service4_info, name='service4_info'),
    
    url(r'^service1/', views.service1, name='service1'),
    url(r'^service2/', views.service2, name='service2'),
    url(r'^service2ing/', views.service2ing, name='service2ing'),
    url(r'^service3/', views.service3, name='service3'),
    url(r'^service3ing/', views.service3ing, name='service3ing'),
    url(r'^service4/', views.service4, name='service4'),
    url(r'^service5/', views.service5, name='service5'),


    url(r'^test/', views.test, name='test'),
]  + static(settings.MEDIA_URL, document_root = settings.MEDIA_ROOT) 

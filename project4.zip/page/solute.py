import eml_parser
import email
import glob

import re
import quopri
import chardet

from langdetect import detect
from bs4 import BeautifulSoup
import base64

from email import policy
from email.parser import BytesParser

# Remove html code ver 1.0
def rm_html(text):
    try:
        body = re.search('<body.*/body>', text, re.I|re.S)
        body = body.group() 
        body = re.sub('<style.*?>.*?</style>', '', text, 0, re.I|re.S)
        body = re.sub('<script.*?>.*?</script>', '', body, 0, re.I|re.S)
        body = re.sub('<.+?>', '', body, 0, re.I|re.S)
        body = re.sub('&nbsp;|\t|\r|\n|&#39;|&gt;|=\n|=0A|&#8211;|\xa0|<br>', '', body)
        body = body.replace('  ', '').replace('&#233;', 'e').replace('&#228;', 'ä').replace('&#223;', 'ß').replace('&#252;','ü')
    except:
        body = re.sub('&nbsp;|\t|\r|\n|&#39;|&gt;|=\n|=0A|&#8211;|\xa0|<br>', '', text)
        body = re.sub('<script.*?>.*?</script>', '', body, 0, re.I|re.S)
        body = body.replace('  ', '').replace('&#233;', 'e').replace('&#228;', 'ä').replace('&#223;', 'ß').replace('&#252;','ü')
        
    return body

# Remove html code ver 2.0
def rm_html_two(text):
    body = re.sub('<style.*?>.*?</style>', '', text, 0, re.I|re.S)
    body = re.sub('(<([^>]+)>)', '', body)
    body = re.sub('&nbsp;|\t|\r|\n|&#39;|&gt;|=\n|=0A|&#8211;|\xa0|<br>', '', body)
    body = body.replace('  ', '').replace('\r', '').replace('\n', '')
    body = body.replace('  ', '').replace('&#233;', 'e').replace('&#228;', 'ä').replace('&#223;', 'ß').replace('&#252;','ü')
    return body

# Decode encoded base64 type 
def change_base(mail_body):
    mail_body = mail_body.encode()
    mail_body = base64.b64decode(mail_body)
    return mail_body.decode()

# Read mail body way_1
def trans_way_1(mail_body):
    if len(mail_body) == 1:
        mail_body = mail_body[0].get_payload()
    elif len(mail_body) == 2:
        mail_body = mail_body[1].get_payload()
    if len(mail_body) == 0:
        real_text = ''
    else:
        try:
            decode_text = quopri.decodestring(mail_body)
            encoding_type = chardet.detect(decode_text)
            text = decode_text.decode(encoding_type['encoding'])
            # real_text = rm_html(text)
            try:
                real_text = rm_html_two(text)
            except:
                real_text = rm_html(text)
        except:
            try:
            # real_text = rm_html(mail_body)
                real_text = rm_html_two(mail_body)
            except:
                real_text = mail_body
    return real_text

# Read mail body way_2
def trans_way_2(mail_body):
    if len(mail_body) == 0:
        real_text = ''
    else:
        try:
            decode_text = quopri.decodestring(mail_body)
            encoding_type = chardet.detect(decode_text)
            text = decode_text.decode(encoding_type['encoding'])
            # real_text = rm_html(text)
            real_text = rm_html_two(text)
        except:
            code_text = mail_body.encode()
            encoding_type = chardet.detect(code_text)
            if encoding_type['encoding'] == 'SHIFT_JIS':
                text = code_text.decode('shift_jisx0213')
            else:
                text = code_text.decode(encoding_type['encoding'])
            # real_text = rm_html(text)
            real_text = rm_html_two(text)
    return real_text
import solute
import imapclient
from imapclient import IMAPClient
import pyzmail

def keyword_filter(userid, userpw, filter_keyword):
    with IMAPClient(host="imap.gmail.com") as client:
        # 입력받은 아이디로 로그인 - 1
        client.login(userid, userpw)
        # client.login('kjix9513@gmail.com', '951362gu')
        client.select_folder('[Gmail]/스팸함')
        messages = client.search(['NOT', 'DELETED'])
        response = client.fetch(messages, ['FLAGS', 'RFC822.SIZE'])

        UIDs=[]
        for message_id, data in response.items():    
            UIDs.append(message_id)

    # 입력받은 아이디로 로그인 - 2
    imap = imapclient.IMAPClient('imap.gmail.com', ssl=True)
    imap.login(userid, userpw)
    # imap.login('kjix9513@gmail.com', '951362gu')
    imap.select_folder('[Gmail]/스팸함', readonly=True)
    msg = imap.fetch(UIDs,['BODY[]'])

    title_list = []
    text_list = []

    i = 0
    for uid in UIDs:
        print(i, '번째 스펨메일')
        pyz = pyzmail.PyzMessage.factory(msg[uid][b'BODY[]'])
        from_ = pyz.get_addresses('from')[0][1]
        print(from_)
        title_ = pyz.get_addresses('subject')[0][0]
        print(title_)
        text_ = pyz.get_payload()
        try:
            try:
                text_ = solute.rm_html_two(text_)
            except:
                text_ = solute.rm_html(text_)
        except:
            text_ = 'Read Fail'

        title_list.append(title_)
        text_list.append(text_)
        
        i+=1
        print('='*50)

    # 웹에서 키워드 입력 받아와서 리스트에 저장
    filter_keyword_list = []
    for keyword in filter_keyword:
        filter_keyword_list.append(keyword)

    # filter_keyword_list = ['게임', '가방', '서류']

    # 키워드가 있는 메일의 위치 파악---------------------------------------------------------
    i = 0
    filtered_place = []
    for filter_key in filter_keyword_list:
        for i in range(len(title_list)):
            if filter_key in text_list[i]:
                filtered_place.append(i)

    my_set = set(filtered_place)
    filtered_place = list(my_set)

    # return filtered_title => 필터링된 이메일 제목이 담긴 리스트
    filtered_title = []
    for pl in filtered_place:
        filtered_title.append(title_list[pl])
    
    return filtered_title
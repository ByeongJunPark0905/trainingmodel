# 모델 테스트! 

import pandas as pd
from konlpy.tag import Okt
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.models import load_model
import numpy as np

def don_t_use_word(df):
	df['text'] = df['text'].str.replace('[^ㄱ-ㅎㅏ-ㅣ가-힣 ]', '')
	# Stopwords list 
	stopwords=['의', '가', '이', '은', '들', '을', '는', '좀', '잘', '걍', '과', '를', '으로', '자', '에', '와', '한', '하다']

	# 불용어 처리 
	okt = Okt()
	sample_test = []
	for sentence in df['text']:
		temp_x = []
		temp_x = okt.morphs(sentence, stem=True)
		temp_x = [word for word in temp_x if not word in stopwords]
		sample_test.append(temp_x)
	return sample_test

def Tokenizer_(sample_test): 
	# 토큰화 
	tokenizer = Tokenizer()
	tokenizer.fit_on_texts(sample_test)
	sample_test = tokenizer.texts_to_sequences(sample_test)
	return sample_test

# 모델 불러오기, 
def loadmodel():
	# 경로 변경 필요 
	model = load_model('page/model/EmailBodymodel.h5')
	return model


# 모델 예측값  
def predict_email_(model,sample_test):
	my_predict=model.predict(sample_test)

	return my_predict

def body_(df):
    print('불용어처리 <<<<')
    sample_test = don_t_use_word(df)
    print('토큰화 <<<<')
    sample_test = Tokenizer_(sample_test)
    print('모델 읽어오기 <<<<')
    model = loadmodel()
    print('예측 결과 뽑아내기 <<<<')
    my_predict = predict_email_(model, sample_test)
    return my_predict
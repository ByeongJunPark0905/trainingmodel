from django.shortcuts import render
from django.contrib.auth.models import User
from django.contrib import auth # 계정에 대한 권한을 다룸
from django.shortcuts import redirect
from django.http import HttpResponse

from .forms import LoginForm
# Create your views here.
# redirect는 render와 달리 context값 전송 불가
from .scrapModel import mail_scrap
from .headerModel import head_
from .bodyModel import body_
from .def_filter_spame import keyword_filter

# songteagyong@gmail.com
def main(req):
    return render(req, 'main.html')


def login2(req):
    return render(req, 'login2.html')

def login3(req):
    return render(req, 'login3.html')
    

# def logining(req):
#     if req.method == 'POST':
#         try:
#             userid = req.POST['userid']
#             userpw = req.POST['userpw']
#             req.session['userid'] = userid
#             req.session['userpw'] = userpw
            
#             print(req.session.session_key)
#             return render(req, 'logining.html')

#         except:
#             return redirect('/login/')
            

def service2_info(req):
    return render(req, 'service2_info.html')
def service3_info(req):
    return render(req, 'service3_info.html')
def service4_info(req):
    return render(req, 'service4_info.html')


def service1(req):
    return render(req, 'service1.html')

def service2(req):
    userid = req.POST['userid']
    userpw = req.POST['userpw']
    req.session['userid'] = userid
    req.session['userpw'] = userpw
    return render(req, 'service2.html')
def service2ing(req):
    print('서비스 2번 진행 ..')
    userid = req.session['userid']
    userpw = req.session['userpw']
    print(userid+', '+userpw)
    # 메일 스크랩
    df = mail_scrap(userid, userpw)
    print(df.columns, 'dataframe 생성 완료..')
    # 헤더 모델
    print('헤더 모델 실행')
    # head_pred = head_(df)
    # print(head_pred)

    # 바디 모델
    print('바디 모델 실행')
    body_pred = body_(df)
    print(body_pred)
    
    return render(req, 'service2.html')

def service3(req):
    print('서비스 3번 진행 ..')
    userid = req.POST['userid']
    userpw = req.POST['userpw']
    req.session['userid'] = userid
    req.session['userpw'] = userpw
    return render(req, 'service3.html')
def service3ing(req):
    print()
    userid = req.session['userid']
    userpw = req.session['userpw']
    print(userid+', '+userpw)
    return render(req, 'service3.html')


def service4(req):
    return render(req, 'service4.html')

def service5(req):
    return render(req, 'service5.html')


import socket
def test(req):
    t_host = '127.0.0.1'
    t_port = 80
    # 객체 생성
    print('객체 생성')
    client = socket.socket(socket.AF_INET, socket.SOCK_DGRAM) # (ipv4 이용, UDP방식)
    print('객체 client', client)
    # 데이터 보내기
    print('데이터 보내기')
    client.sendto('This is Apple', (t_host, t_port))
    data, addr = client.recfrom(4096)

    print(data, '>>>>>>>')
    return render(req, 'service5.html')
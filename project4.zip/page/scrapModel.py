from . import solute
import email, eml_parser
from email import policy
from email.parser import BytesParser

import imapclient, imaplib
import pandas as pd

import glob, re
import quopri, chardet, base64
from langdetect import detect
from bs4 import BeautifulSoup

def mail_scrap(userid, userpw):
    print('mail scrap code ..')
    #IMAP 서버 접속
    imap = imaplib.IMAP4_SSL('imap.gmail.com')
    #IMAP 서버 로그인
    imap.login(userid, userpw)
    print('1차 로그인')
    #INBOX 선택
    imap.select('inbox') 

    imap_obj = imapclient.IMAPClient('imap.gmail.com', ssl=True)
    imap_obj.login(userid, userpw)
    print('2차 로그인')
    imap_obj.select_folder('INBOX', readonly=True)
    email_ = imap_obj.search(['ALL'])

    # 가장 최근 메일 100개만 읽어오도록
    email_.reverse()
    mail_list = []
    for index in email_:
        mail_list.append(index)
    mail_list = mail_list[:100]
    for i in range(len(mail_list)):
        mail_list[i] = str(mail_list[i]).encode()

    # 정제되지 않은 사용자 이메일 읽어오기
    print('정제되지 않은 사용자 이메일 읽어오기')
    raw_email_list = []
    i = 0
    for mail in mail_list:
        result, data = imap.uid('fetch', mail, '(RFC822)')
        raw_email = data[0][1]
        raw_email_list.append(raw_email)
        i+=1

    subject_list = []
    hash_list = []
    from_list = []
    from_ip_list = []
    text_list = []

    # 이메일에서 컬럼 추출-------------------------------------------------
    i = 0
    for raw_email in raw_email_list:
        try:
            ep = eml_parser.EmlParser()
            parsed_eml = ep.decode_email_bytes(raw_email)
        except:
            pass

        # 이메일 본문 내용 읽기
        try:
            decode_eml = raw_email.decode()
            msg = email.message_from_string(decode_eml)
            mail_body = msg.get_payload()
        except:
            mail_body = 'Fail to read'
        
        try:
            if parsed_eml['body'][0]['content_header']['content-transfer-encoding'][0] == 'base64':
                mail_body = solute.change_base(mail_body)
            elif parsed_eml['body'][0]['content_header']['content-transfer-encoding'][0] == 'BASE64':
                mail_body = solute.change_base(mail_body)         
        except:
            pass
            
        if type(mail_body) == list:
            mail = solute.trans_way_1(mail_body)
        elif type(mail_body) == str:
            mail = solute.trans_way_2(mail_body)
        else:
            mail = 0
        text_list.append(mail)

        # 이메일 제목
        try:
            subject_list.append(parsed_eml['header']['subject'])
        except:
            subject_list.append('-')

        # 이메일 해쉬값
        try:
            hash_list.append(parsed_eml['body'][0]['hash'])
        except:
            hash_list.append('-')

        # 이메일 송신자 
        try:
            if len(parsed_eml['header']['subject']) == 0:
                from_list.append('-')
            else:
                from_list.append(parsed_eml['header']['from'])
        except:
            from_list.append('-')

        # 송신 IP
        try:
            try:
                tex1 = parsed_eml['header']['received'][1]['from'][0]
                tex2 = parsed_eml['header']['received'][1]['from'][1]
            except:
                tex1 = parsed_eml['header']['received'][0]['from'][0]
                tex2 = parsed_eml['header']['received'][0]['from'][1]
            
            if '.kr' in tex1:
                real_ip = tex2
            elif '.com' in tex1:
                real_ip = tex2
            else:
                real_ip = tex1
            from_ip_list.append(real_ip)
            
        except:
            from_ip_list.append('-')
        i+=1
    df = pd.DataFrame()

    df['ip'] = from_ip_list
    df['from'] = from_list
    df['hash'] = hash_list
    df['title'] = subject_list
    df['text'] = text_list
    
    print('dataframe create ..')
    df.to_csv('aaa.csv')
    return df

# imap.close()
# imap.logout()
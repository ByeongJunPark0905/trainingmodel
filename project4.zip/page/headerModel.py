import pandas as pd
import ipaddress
import re
import socket
import sys
from tensorflow.keras.models import load_model


def read_email(test_email):

    test_email = test_email[['ip', 'from']]

    ip_list = []
    for ip in test_email['ip'].values:
        try:
            ip_list.append(int(ipaddress.IPv4Address(ip)))
        except:
            ip_list.append(0)
    test_email['ip_list'] = ip_list

    return test_email


def split_sender(test_email, user_list, res_list):
    new_user_list = []
    new_res_list = []

    for email in test_email['from'].values:
        
        user = email.split('@')[0]
        res = email.split('@')[1]

        user_list.append(str(user))
        new_user_list.append(str(user))
        res_list.append(str(res))
        new_res_list.append(str(res))
    
    test_email['user_list'] = new_user_list
    test_email['res_list'] = new_res_list

    return test_email, user_list, res_list



def add_user(new_list, new_list2, test_email):
    idx = 0
    idx2 = 0
    new_result_list = []
    new_result_list2 = []

    for i, values in enumerate(test_email['user_list']):
        if values in new_list:
            idx = new_list.index(values)
            new_result_list.append(idx)
        else:
            new_list.append(values)
            idx = new_list.index(values)
            new_result_list.append(idx)
    
    test_email['user_'] = new_result_list


    for i, values in enumerate(test_email['res_list']):
        if values in new_list2:
            idx2 = new_list2.index(values)
            new_result_list2.append(idx2)
        else:
            new_list2.append(values)
            idx2 = new_list2.index(values)
            new_result_list2.append(idx2)

    test_email['res_'] = new_result_list2

    return test_email

def test_frame(test_email):
    test_ = pd.DataFrame(test_email, columns=['ip_list', 'user_', 'res_'])
    test_ = test_.astype(float)
    return test_

def loadmodel():
	model = load_model('page/model/final_model.h5')
	return model

def predict_email_(model,test_):
	my_predict=model.predict(test_)

	return my_predict

def head_(df):
    new_list = list(pd.read_csv('page/data/model_list.csv').values)
    new_list2 = list(pd.read_csv('page/data/model_list2.csv').values)
    
    print('csv 파일 읽기 <<<<<<<')
    test_email = read_email(df)
    print('user name & domain get  <<<<<<<')
    test_email, user_list, res_list = split_sender(test_email, new_list, new_list2)
    print('add new user  <<<<<<<')
    test_email = add_user(new_list, new_list2, test_email)
    print('데이터프레임 정리  <<<<<<<')
    test_ = test_frame(test_email)
    print('모델 불러오기  <<<<<<<')
    model = loadmodel()
    print('예측하기  <<<<<<<')
    return predict_email_(model, test_)
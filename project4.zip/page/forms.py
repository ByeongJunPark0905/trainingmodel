from django import forms

class LoginForm(forms.Form):
    userid = forms.CharField()
    userpw = forms.CharField()